import { Page } from '@playwright/test';

export class ProductPage {

  constructor(private page: Page) {}

  async addToCart() {
    await this.page.locator('a.btn-success').click();
  }

  async acceptAlert() {
    this.page.on('dialog', async dialog => {
      await dialog.accept();
    });
  }
}