import { Page, expect } from '@playwright/test';

export class CartPage {

  constructor(private page: Page) {}

  async verifyProduct(productName: string) {
    await expect(
      this.page.locator(`text=${productName}`)
    ).toBeVisible();
  }
}