import { Page } from '@playwright/test';

export class HomePage {
  constructor(private page: Page) {}

  async open() {
    await this.page.goto('/');
  }

  async selectProduct(productName: string) {
    await this.page.locator(`a:has-text("${productName}")`).click();
  }

  async openCart() {
    await this.page.locator('#cartur').click();
  }
}