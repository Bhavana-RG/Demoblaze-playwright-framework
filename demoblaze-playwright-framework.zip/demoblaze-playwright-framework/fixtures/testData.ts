export const products = {
  laptop: 'Sony vaio i5',
  mobile: 'Samsung galaxy s6'
};