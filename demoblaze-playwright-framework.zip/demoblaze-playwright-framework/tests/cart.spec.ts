import { test } from '@playwright/test';
import { HomePage } from '../pages/HomePage';
import { ProductPage } from '../pages/ProductPage';
import { CartPage } from '../pages/CartPage';
import { products } from '../fixtures/testData';

test('User can add product to cart', async ({ page }) => {

  const home = new HomePage(page);
  const product = new ProductPage(page);
  const cart = new CartPage(page);

  await home.open();

  await home.selectProduct(products.laptop);

  await product.acceptAlert();

  await product.addToCart();

  await home.openCart();

  await cart.verifyProduct(products.laptop);
});